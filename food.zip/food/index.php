<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Food </title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="logo">
            <a href="index.php">
                <img src="images/logo2.png" alt="Food Logo" class="logo-img">
                <h1>Dream food</h1>
            </a>
        </div>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="menu.php">Menu</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="admin.php">admin</a></li>
            
        </ul>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h2>Welcome to Dream food</h2>
            <p>Where every bite is a moment of bliss! We specialize in creating delicious, handcrafted food that's perfect for any occasion. Whether you're celebrating a special day or simply indulging in a treat, our dishes are prepared with love and the finest ingredients.</p>
            <div class="hero-buttons">
                <a href="menu.php" class="btn btn-primary">Our Menu</a>
                <a href="javascript:history.back()" class="btn btn-secondary">Go Back</a>
            </div>
        </div>
    </section>

    <!-- Featured Menu Section -->
    <section class="featured-menu">
        <h3 class="section-title">Featured Items</h3>
        <div class="food-menu-container">
            <!-- Menu Item 1 -->
            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Smoky Burger.jpg" alt="Smoky Burger" class="img-responsive">
                </div>
                <div class="food-menu-desc">
                    <h4>Smoky Burger</h4>
                    <p class="food-price">Rs. 1000.00</p>
                    <p class="food-detail">Made with Italian Sauce, Chicken, and organic vegetables.</p>
                    <a href="order.php?id=1" class="btn btn-order">Order Now</a>
                </div>
            </div>

            <!-- Menu Item 2 -->
            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Nice Burger.jpg" alt="Nice Burger" class="img-responsive">
                </div>
                <div class="food-menu-desc">
                    <h4>Nice Burger</h4>
                    <p class="food-price">Rs. 1500.00</p>
                    <p class="food-detail">Made with Italian Sauce, Chicken, and organic vegetables.</p>
                    <a href="order.php?id=2" class="btn btn-order">Order Now</a>
                </div>
            </div>

            <!-- Menu Item 3 -->
            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/menu-pizza.jpg" alt="Combo Pack" class="img-responsive">
                </div>
                <div class="food-menu-desc">
                    <h4>Combo Pack</h4>
                    <p class="food-price">Rs. 1450.00</p>
                    <p class="food-detail">Made with Italian Sauce, Chicken, and organic vegetables.</p>
                    <a href="order.php?id=3" class="btn btn-order">Order Now</a>
                </div>
            </div>

            <!-- Menu Item 4 -->
            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/menu-pizza.jpg" alt="Masala Special" class="img-responsive">
                </div>
                <div class="food-menu-desc">
                    <h4>Masala Special</h4>
                    <p class="food-price">Rs. 1800.00</p>
                    <p class="food-detail">Made with Italian Sauce, Chicken, and organic vegetables.</p>
                    <a href="order.php?id=4" class="btn btn-order">Order Now</a>
                </div>
            </div>

            <!-- Menu Item 5 -->
            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/menu-momo.jpg" alt="Chicken Steam Momo" class="img-responsive">
                </div>
                <div class="food-menu-desc">
                    <h4>Chicken Steam Momo</h4>
                    <p class="food-price">Rs. 2100.00</p>
                    <p class="food-detail">Made with Italian Sauce, Chicken, and organic vegetables.</p>
                    <a href="order.php?id=5" class="btn btn-order">Order Now</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <p>Designed By: Kalana Champika</p>
            <div class="social-links">
                <p>Follow us on:</p>
                <a href="#" class="social-icon"><img src="https://img.icons8.com/fluent/50/000000/facebook-new.png" alt="Facebook"></a>
                <a href="#" class="social-icon"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png" alt="Instagram"></a>
                <a href="#" class="social-icon"><img src="https://img.icons8.com/fluent/48/000000/twitter.png" alt="Twitter"></a>
            </div>
        </div>
    </footer>
</body>
</html>