<html>
<head>
   
    <title>food</title>
    <link rel="stylesheet" href="header.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>Dream Food</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="aboutus.php">About Us</a></li>
                <li><a href="contactus.php">Contact Us</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Register</a></li>
            </ul>
        </nav>
    </header>
    
    </body>
</html>