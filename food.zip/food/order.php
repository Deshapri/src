<?php
include "header.php";
?>


<html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order - food</title>
    <link rel="stylesheet" href="order.css">
</head>
<body>
     <main>
        <section class="order-form">
            <h2>Place Your Order</h2>
            <form action="order.php" method="post">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>

                <label for="phone">Telephone Number:</label>
                <input type="tel" id="phone" name="phone" required>

                <label for="cake">Type of food:</label>
                <input type="text" id="food" name="food" required>

                <label for="quantity">Quantity:</label>
                <input type="text" placeholder=" As L / M / S   ex:L-Large -1 "id="quantity" name="quantity"  required>

                <label for="address">Delivery Address:</label>
                <textarea id="address" name="address" rows="4" required></textarea>

                <button type="submit" class="order-now-btn">Submit Order</button>
            </form>
        </section>
    </main>

</body>

<?php
include "footer.php";
?>
</html>