<?php
include "header.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Momo Menu</title>
    <link rel="stylesheet" href="category.css">
</head>
<body>
    <section class="momo-menu">
        <div class="container">
            <h2 class="text-center">Our Momo Selection</h2>
            
            <div class="momo-menu-box">
                <!-- Steam Momo -->
                <div class="momo-menu-item">
                    <div class="momo-img">
                        <img src="images/steam-momo.jpg" alt="Steam Momo" class="img-responsive img-curve">
                    </div>
                    <div class="momo-desc">
                        <h4>Steam Momo</h4>
                        <p class="momo-price">$6.99</p>
                        <p class="momo-detail">Classic steamed dumplings with vegetable/chicken filling</p>
                        <a href="order.php?id=9" class="btn btn-primary">Order Now</a>
                    </div>
                </div>

                <!-- Fried Momo -->
                <div class="momo-menu-item">
                    <div class="momo-img">
                        <img src="images/fried-momo.jpg" alt="Fried Momo" class="img-responsive img-curve">
                    </div>
                    <div class="momo-desc">
                        <h4>Fried Momo</h4>
                        <p class="momo-price">$7.99</p>
                        <p class="momo-detail">Crispy fried dumplings with spicy sauce</p>
                        <a href="order.php?id=10" class="btn btn-primary">Order Now</a>
                    </div>
                </div>

                <!-- Jhol Momo -->
                <div class="momo-menu-item">
                    <div class="momo-img">
                        <img src="images/jhol-momo.jpg" alt="Jhol Momo" class="img-responsive img-curve">
                    </div>
                    <div class="momo-desc">
                        <h4>Jhol Momo</h4>
                        <p class="momo-price">$8.99</p>
                        <p class="momo-detail">Momos served in spicy soup</p>
                        <a href="order.php?id=11" class="btn btn-primary">Order Now</a>
                    </div>
                </div>

                <!-- Paneer Momo -->
                <div class="momo-menu-item">
                    <div class="momo-img">
                        <img src="images/paneer-momo.jpg" alt="Paneer Momo" class="img-responsive img-curve">
                    </div>
                    <div class="momo-desc">
                        <h4>Paneer Momo</h4>
                        <p class="momo-price">$7.99</p>
                        <p class="momo-detail">Cottage cheese filled dumplings</p>
                        <a href="order.php?id=12" class="btn btn-primary">Order Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include "footer.php"; ?>
</body>
</html>