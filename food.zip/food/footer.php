<!DOCTYPE html>
<html>
<head>
    <title>food</title>
    <link rel="stylesheet" href="footer.css">
</head>
<body>
    <main>
      
    </main>
    <footer class="bottom">
        <p>Designed By: kalana champika</p>
        <p>Follow us on: 
       
        
            <a href="#"><img src="https://img.icons8.com/fluent/50/000000/facebook-new.png"/></a>
           
            <a href="#"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png"/></a>
            
            <a href="#"><img src="https://img.icons8.com/fluent/48/000000/twitter.png"/></a>
            
        </p>
    </footer>
</body>
</html>
