<?php
session_start();

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "food";

// Create connection
try {
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    $conn->set_charset("utf8mb4");
} catch (Exception $e) {
    die("Connection error: " . $e->getMessage());
}

// Handle Add/Edit/Delete operations
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $username = $conn->real_escape_string($_POST['username']);
                $email = $conn->real_escape_string($_POST['email']);
                $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                $role = $conn->real_escape_string($_POST['role']);
                $status = $conn->real_escape_string($_POST['status']);
                
                $sql = "INSERT INTO tbl_admin (username, email, password, role, status) 
                        VALUES ('$username', '$email', '$password', '$role', '$status')";
                $conn->query($sql);
                break;

            case 'edit':
                $id = (int)$_POST['id'];
                $username = $conn->real_escape_string($_POST['username']);
                $email = $conn->real_escape_string($_POST['email']);
                $role = $conn->real_escape_string($_POST['role']);
                $status = $conn->real_escape_string($_POST['status']);
                
                $sql = "UPDATE tbl_admin SET 
                        username='$username', 
                        email='$email', 
                        role='$role', 
                        status='$status' 
                        WHERE id=$id";
                $conn->query($sql);
                break;

            case 'delete':
                $id = (int)$_POST['id'];
                $sql = "DELETE FROM tbl_admin WHERE id=$id";
                $conn->query($sql);
                break;
        }
        
        // Redirect to prevent form resubmission
        header("Location: admin.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Management</title>
    <link rel="stylesheet" href="admin-style.css">
    <!-- Add Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="container">
        <h1>Admin Management</h1>

        <!-- Add Admin Modal -->
        <div id="addAdminModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h2>Add New Admin</h2>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="add">
                    <div class="form-group">
                        <label>Username:</label>
                        <input type="text" name="username" required>
                    </div>
                    <div class="form-group">
                        <label>Email:</label>
                        <input type="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label>Password:</label>
                        <input type="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label>Role:</label>
                        <select name="role" required>
                            <option value="admin">Admin</option>
                            <option value="manager">Manager</option>
                            <option value="editor">Editor</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Status:</label>
                        <select name="status" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                    <button type="submit" class="btn-submit">Add Admin</button>
                </form>
            </div>
        </div>

        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col">
                        <h2>Manage Admins</h2>
                    </div>
                    <div class="col">
                        <button class="add-btn" onclick="openModal('addAdminModal')">
                            <i class="fas fa-plus"></i> Add New Admin
                        </button>
                    </div>
                </div>
            </div>
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM tbl_admin ORDER BY id DESC";
                    $result = $conn->query($sql);

                    if ($result && $result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['role']) . "</td>";
                            echo "<td><span class='status " . strtolower(htmlspecialchars($row['status'])) . "'>" 
                                . htmlspecialchars($row['status']) . "</span></td>";
                            echo "<td class='actions'>";
                            echo "<button class='edit-btn' onclick='editAdmin({$row['id']})'>";
                            echo "<i class='fas fa-edit'></i></button>";
                            echo "<button class='delete-btn' onclick='deleteAdmin({$row['id']})'>";
                            echo "<i class='fas fa-trash'></i></button>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6'>No records found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
    // Modal functionality
    function openModal(modalId) {
        document.getElementById(modalId).style.display = "block";
    }

    // Close modal when clicking the X or outside the modal
    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = "none";
        }
    }

    document.querySelectorAll('.close').forEach(function(elem) {
        elem.onclick = function() {
            this.parentElement.parentElement.style.display = "none";
        }
    });

    // Admin CRUD operations
    function editAdmin(id) {
        // Implement edit functionality
        if(confirm('Do you want to edit this admin?')) {
            // You can implement a modal form for editing
            console.log('Editing admin with ID: ' + id);
        }
    }

    function deleteAdmin(id) {
        if(confirm('Are you sure you want to delete this admin?')) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="${id}">
            `;
            document.body.appendChild(form);
            form.submit();
        }
    }
    </script>
</body>
</html>

<?php
$conn->close();
?>