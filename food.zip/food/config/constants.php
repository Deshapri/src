<?php
    // Start Session
    session_start();

    // Create Constants to Store Non Repeating Values
    define('SITEURL', 'http://localhost/your-food-order-site/');  // Change this to your website URL
    define('LOCALHOST', 'localhost');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', '');  // Enter your database password if you have set one
    define('DB_NAME', 'food_order');
    
    // Database Connection
    $conn = mysqli_connect('127.0.0.1', 'root', DB_PASSWORD) or die(mysqli_error($conn));
    // Selecting Database
    $db_select = mysqli_select_db($conn, 'food') or die(mysqli_error($conn));
?>