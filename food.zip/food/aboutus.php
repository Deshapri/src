<?php
include "header.php";
?>
<html>
<head>

    <title>About Us - food </title>
    <link rel="stylesheet" href="aboutus.css">
</head>
<body >
    <div class="about-container">
        <h2>About Us</h2>
        <p>Welcome to <strong>Dream food</strong>, where every food tells a story!</p>
        
        
                <h3>Our Mission</h3>
        <p>At Dream food , our mission is to create delicious and beautiful food that bring joy to every occasion. We believe that every celebration deserves a special food, crafted with love and attention to detail.</p>
        
        <h3>Our Story</h3>
        <p>Founded in 2023, Dream food started as a small house with a passion for baking. Over the years, we have grown into a beloved local shop, known for our unique flavors and stunning food designs. Our team of skilled bakers and decorators work tirelessly to ensure that each food is made from the finest ingredients and tailored to your needs.</p>
        
        <h3>What We Offer</h3>
        <ul>
            <li>Custom food for all occasions: birthdays, weddings, anniversaries, and more.</li>
            <li>Wide variety of flavors and designs to choose from.</li>
            <li>Order online or visit our shop for personalized service.</li>
        </ul>
        
        <h3>Join Us</h3>
        <p>We invite you to visit our shop and experience the magic of our food . Follow us on social media to stay updated on our latest creations and special offers!</p>
    </div>

    </body>

 <?php
include "footer.php";
?>

</html>