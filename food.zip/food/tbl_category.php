<?php
include "header.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pizza Menu</title>
    <link rel="stylesheet" href="tbl_category.css">
</head>
<body>
    <section class="pizza-menu">
        <div class="container">
            <h2 class="text-center">Our Pizza Selection</h2>
            
            <div class="pizza-menu-box">
                <!-- Margherita Pizza -->
                <div class="pizza-menu-item">
                    <div class="pizza-img">
                        <img src="images/Margherita Pizza.jpg" alt="Margherita Pizza" class="img-responsive img-curve">
                    </div>
                    <div class="pizza-desc">
                        <h4>Margherita Pizza</h4>
                        <p class="pizza-price">R.S.1200.99</p>
                        <p class="pizza-detail">Fresh tomatoes, mozzarella, basil, olive oil</p>
                        <a href="order.php?id=1" class="btn btn-primary">Order Now</a>
                    </div>
                </div>

                <!-- Pepperoni Pizza -->
                <div class="pizza-menu-item">
                    <div class="pizza-img">
                        <img src="images/Pepperoni Pizza.jpg" alt="Pepperoni Pizza" class="img-responsive img-curve">
                    </div>
                    <div class="pizza-desc">
                        <h4>Pepperoni Pizza</h4>
                        <p class="pizza-price">R.S.800.99</p>
                        <p class="pizza-detail">Pepperoni, mozzarella, tomato sauce</p>
                        <a href="order.php?id=2" class="btn btn-primary">Order Now</a>
                    </div>
                </div>

                <!-- BBQ Chicken Pizza -->
                <div class="pizza-menu-item">
                    <div class="pizza-img">
                        <img src="images/BBQ Chicken Pizza.jpg" alt="BBQ Chicken Pizza" class="img-responsive img-curve">
                    </div>
                    <div class="pizza-desc">
                        <h4>BBQ Chicken Pizza</h4>
                        <p class="pizza-price">R.S.2280.99</p>
                        <p class="pizza-detail">Grilled chicken, BBQ sauce, red onions, mozzarella</p>
                        <a href="order.php?id=3" class="btn btn-primary">Order Now</a>
                    </div>
                </div>

                <!-- Vegetarian Pizza -->
                <div class="pizza-menu-item">
                    <div class="pizza-img">
                        <img src="images/Vegetarian Pizza.jpg" alt="Vegetarian Pizza" class="img-responsive img-curve">
                    </div>
                    <div class="pizza-desc">
                        <h4>Vegetarian Pizza</h4>
                        <p class="pizza-price">R.S.2550.99</p>
                        <p class="pizza-detail">Bell peppers, mushrooms, onions, olives, tomatoes</p>
                        <a href="order.php?id=4" class="btn btn-primary">Order Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    
    <?php include "footer.php"; ?>
</body>
</html>



