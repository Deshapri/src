<?php
include "header.php";
?>

<html>
<head>

    <title>Contact Us - food</title>
    <link rel="stylesheet" href="contactus.css">
</head>
<body>
    
    <div class="contact-container">
        <h2>Contact Us</h2>
        <div class="contact-details">
            <p><strong>Address:</strong>Meda Kadigamuwa,Ihala Kadigamuwa</p>
            <p><strong>Phone:</strong> +94 0785813895</p>
            <p><strong>Email:</strong> <a href="mailto:champika1019@gmail.com">champika1019@gmail.com</a></p>
        </div>
        <div class="social-media">
            <h3>Follow Us</h3>
            <p>
            <a href="#"><img src="https://img.icons8.com/fluent/50/000000/facebook-new.png"/></a>
           
           <a href="#"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png"kalana champika/></a>
           
           <a href="#"><img src="https://img.icons8.com/fluent/48/000000/twitter.png"/></a>
            </p>
        </div>
    </div>
<?php
include "footer.php";
?>
</body>
</html>