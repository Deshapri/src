<?php
include "header.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu - Food</title>
    <link rel="stylesheet" href="menu.css"> <!-- Link to the CSS file -->
</head>
<body>

    <!-- Food Menu Section -->
    <section class="Food-menu">
        <div class="container">
            <h2 class="text-center">Our Food Menu</h2>

            
           <a href="tbl_category.php">  
    <div class="box-3 float-container">
        <img src="images/pizza.jpg" alt="Pizza" class="img-responsive img-curve">
        <h3 class="float-text text-white">Pizza</h3>
       
    
       </div>
    </a>


    

                <a href="tbl_category">
                    <div class="box-3 float-container">
                        <img src="images/burger.jpg" alt="Burger" class="img-responsive img-curve">
                        <h3 class="float-text text-white">Burger</h3>
                    </div>
                </a>

                <a href="tbl_category">
                    <div class="box-3 float-container">
                        <img src="images/momo.jpg" alt="Momo" class="img-responsive img-curve">
                        <h3 class="float-text text-white">Momo</h3>
                    </div>
                </a>

                <!-- Repeat items as necessary, consider using a loop in PHP to avoid repetition -->

            </div>

            <div class="clearfix"></div>
        </div>
    </section>

    <?php
    include "footer.php";
    ?>
</body>
</html>

